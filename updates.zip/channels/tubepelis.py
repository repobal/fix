# -*- coding: utf-8 -*-

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, servertools, tmdb


host = 'https://www.tubepelis.com/'


def do_downloadpage(url, post=None, headers=None):
    data = httptools.downloadpage(url, post=post, headers=headers).data

    return data


def mainlist(item):
    return mainlist_pelis(item)


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie', text_color = 'deepskyblue' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host, search_type = 'movie' ))

    url = host + 'pelicula/ultimas-peliculas/'

    itemlist.append(item.clone( title = 'Últimas', action = 'list_all', url = url, grp = url, search_type = 'movie', text_color='cyan' ))

    url = host + 'pelicula/peliculas-mas-vistas/'

    itemlist.append(item.clone( title = 'Más vistas', action = 'list_all', url = url, grp = url, search_type = 'movie' ))

    url = host + 'pelicula/peliculas-mas-votadas/'

    itemlist.append(item.clone( title = 'Más valoradas', action = 'list_all', url = url, grp = url, search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Por género', action = 'generos', search_type = 'movie' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(host)

    bloque = scrapertools.find_single_match(data, '>Selecciona tu categoria<(.*?)</ul>')

    matches = scrapertools.find_multiple_matches(bloque, 'href="(.*?)">(.*?)</a>')

    for url, title in matches:
        if config.get_setting('descartar_xxx', default=False):
            if title == 'Eroticas +18': continue

        itemlist.append(item.clone( action = 'list_all', title = title, url = url, grp = url, text_color = 'deepskyblue' ))

    return itemlist


def list_all(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    if '>Resultados para' in data:
        bloque = scrapertools.find_single_match(data, '>Resultados para(.*?)</div> </div> </div>')
    else:
        bloque = scrapertools.find_single_match(data, '<center>(.*?)</li></ul>')

    matches = scrapertools.find_multiple_matches(bloque, '<li class="peli_bx br1px brdr10px ico_a">(.*?)</div></div></div>')
    if not matches: matches = scrapertools.find_multiple_matches(bloque, '<li class="peli_bx br1px brdr10px ico_a">(.*?)</div> </div>')
    if not matches: matches = scrapertools.find_multiple_matches(bloque, '<li class="peli_bx br1px brdr10px ico_a">(.*?)</div></div></div>')

    for match in matches:
        url = scrapertools.find_single_match(match, '<a href="(.*?)"')

        title = scrapertools.find_single_match(match, 'title="(.*?)"')
        if not title: title = scrapertools.find_single_match(match, 'alt="(.*?)"')

        if not url or not title: continue

        title = title.replace('&#039;s', "'s")

        thumb = scrapertools.find_single_match(match, '<img src="(.*?)"')

        itemlist.append(item.clone( action = 'findvideos', url = url, title = title, thumbnail = thumb,
                                    contentType = 'movie', contentTitle = title, infoLabels={'year': '-'} ))

    tmdb.set_infoLabels(itemlist)

    if itemlist:
        if '<ul class="nav bgdeg4 bold brdr10px bxshd2 clr fs18px lnht30px liasbrdr10px lstinl pd10px txt_cen white">' in data:
            next_page = scrapertools.find_single_match(data, '<ul class="nav bgdeg4 bold brdr10px bxshd2 clr fs18px lnht30px liasbrdr10px lstinl pd10px txt_cen white">.*?</b>.*?<a href="(.*?)".*?</ul>')

            if next_page:
                if '?page=' in next_page or '&page=' in next_page:
                    if not item.grp:
                        next_page = host + next_page
                    else:
                        next_page = item.grp + next_page

                    itemlist.append(item.clone( title = 'Siguientes ...', url = next_page, action = 'list_all', text_color='coral' ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    matches = scrapertools.find_multiple_matches(data, '<iframe src="(.*?)"')

    ses = 0

    for url in matches:
        ses += 1

        if '.mystream.' in url: continue

        servidor = servertools.get_server_from_url(url)
        servidor = servertools.corregir_servidor(servidor)

        if servertools.is_server_available(servidor):
            if not servertools.is_server_enabled(servidor): continue
        else:
            if not config.get_setting('developer_mode', default=False): continue

        other = servidor

        if servidor == 'various': other = servertools.corregir_other(url)

        if servidor == other: other = ''

        elif not servidor == 'directo':
           if not servidor == 'various': other = ''

        if servidor == 'directo':
            if not config.get_setting('developer_mode', default=False): continue
            other = url.split("/")[2]
            other = other.replace('https:', '').strip()

        itemlist.append(Item( channel = item.channel, action = 'play', server = servidor, url = url, language = 'Lat', other = other ))

    if not itemlist:
        if not ses == 0:
            platformtools.dialog_notification(config.__addon_name, '[COLOR tan][B]Sin enlaces Soportados[/B][/COLOR]')
            return

    return itemlist


def search(item, texto):
    logger.info()
    try:
       url = host + 'buscar/?q=' + texto.replace(" ", "+")
       item.url = url
       item.grp = host + 'buscar/'
       return list_all(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []

