# -*- coding: utf-8 -*-

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, servertools, tmdb


host = 'https://zonahindi.blogspot.com/'


perpage = 31


def do_downloadpage(url, post=None, headers=None):
    data = httptools.downloadpage(url, post=post, headers=headers).data

    return data


def mainlist(item):
    return mainlist_pelis(item)


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie', text_color = 'deepskyblue' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + 'feeds/posts/default?alt=json-in-script&orderby=published&sortorder=descending&max-results=31', search_type = 'movie' ))

    itemlist.append(item.clone( title = '[B]Youtube:[/B]', folder=False, thumbnail=config.get_thumb('youtube'), text_color='moccasin' ))

    itemlist.append(item.clone( title = '- BollyWood', action = 'list_tubes', url = 'https://www.youtube.com/watch?v=vJzc9TVjAik&list=PLm5FzDFBgJT00KrnoYZbvH3FpJyjqXiju', text_color = 'paleturquoise'))

    return itemlist


def list_all(item):
    logger.info()
    itemlist = []

    if not item.page:
        item.page = 1
        item.url = item.url + '&start-index=1'

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    data = data.replace('}]}});', '}]},')

    data = data.replace('{"id":{"$t":"', '<INI>').replace('}]},', '<FIN>')

    matches = scrapertools.find_multiple_matches(str(data), '<INI>(.*?)<FIN>')

    for match in matches:
        match = match.replace('=\\', '=').replace('\\"', '"')

        match = match.replace('"type":"text","$t":"', 'title="')

        url = scrapertools.find_single_match(str(match), 'iframe src="(.*?)"')

        title = scrapertools.find_single_match(str(match), 'title="(.*?)"').strip()

        if not url or not title: continue

        url = url.replace('\\/', '/')

        year = scrapertools.find_single_match(title, '(\d{4})')
        if year: title = title.replace('(' + year + ')', '').strip()
        else: year: year = '-'

        itemlist.append(item.clone( action='findvideos', url=url, title=title,
                                    contentType = 'movie', contentTitle = title, infoLabels = {'year': year} ))

    tmdb.set_infoLabels(itemlist)

    if itemlist:
        page = item.page + 1
        prox_page = page * perpage

        act_page = item.url.split('&start-index=')[0]

        next_page = act_page + '&start-index=' + str(prox_page)

        itemlist.append(item.clone( title = 'Siguientes ...', action='list_all', url=next_page, page=page, text_color='coral' ))

    return itemlist


def list_tubes(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    bloque = scrapertools.find_single_match(str(data), '"playlist":.*?"playlist":.*?"title":(.*?)$')

    matches = scrapertools.find_multiple_matches(str(bloque), 'playlistPanelVideoRenderer":.*?simpleText":"(.*?)".*?"videoId":"(.*?)".*?"playlistId"')

    for title, _id in matches:
        if not _id or not title: continue

        title = title.replace('(Documental)', '').replace('(DOCUMENTAL COMPLETO)', '').replace('- Documental', '').replace('| DW Documental', '').replace('| HD Documental', '')
        title = title.replace('🇪🇦', '').replace('☠️', '').replace('🌎', '').replace('✅✅✅', '').strip()

        thumb = 'https://i.ytimg.com/vi/' + _id + '/hqdefault.jpg'

        url = 'https://www.youtube.com/watch?v=' + _id

        itemlist.append(item.clone( action = 'findvideos', title = title, url = url, thumbnail = thumb ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    url = item.url

    if item._url:
        data = do_downloadpage(item._url)
        data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

        _url = scrapertools.find_single_match(data, '<iframe src="(.*?)"')

        if _url: url = _url

    if '.youtube.' in url:
        itemlist.append(Item( channel = item.channel, action = 'play', server = 'youtube', language = 'Vo', url = item.url ))

        return itemlist

    url = url.replace('\\u0026', '&').replace('&amp;', '&')

    servidor = servertools.get_server_from_url(url)

    other = ''
    if servidor == 'directo':
        try:
           if '//' in url: other = url.split('//')[1]
           else: other = url.split('/')[1]

           other = other.split('/')[0]
        except:
           other = url
    else:
       if servidor == 'various': other = servertools.corregir_other(url)
       elif servidor == 'zures': other = servertools.corregir_zures(url)

    itemlist.append(Item( channel = item.channel, action = 'play', title = '', url = url, server = servidor,
                          language = 'Vo', other = other.capitalize() ))

    return itemlist


def list_search(item):
    logger.info()
    itemlist = []

    if not item.page:
        item.page = 1
        item.url = item.url + '&start-index=1'

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    data = data.replace('}]}});', '}]},')

    data = data.replace('{"id":{"$t":"', '<INI>').replace('}]},', '<FIN>')

    matches = scrapertools.find_multiple_matches(str(data), '<INI>(.*?)<FIN>')

    for match in matches:
        match = match.replace('=\\', '=').replace('\\"', '"')

        match = match.replace('"type":"text","$t":"', 'title="')

        _url = scrapertools.find_single_match(str(match), '"text/html".*?"href":"(.*?)"')

        title = scrapertools.find_single_match(str(match), 'title="(.*?)"').strip()

        if not _url or not title: continue

        _url = _url.replace('\\/', '/')

        year = scrapertools.find_single_match(title, '(\d{4})')
        if year: title = title.replace('(' + year + ')', '').strip()
        else: year: year = '-'

        itemlist.append(item.clone( action='findvideos', _url=_url, title=title,
                                    contentType = 'movie', contentTitle = title, infoLabels = {'year': year} ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def play(item):
    logger.info()
    itemlist = []

    servidor = item.server
 
    url = item.url

    if url:
        if '/vsembed.' in url:
            return 'Servidor [COLOR plum]No Soportado[/COLOR]'

        servidor = servertools.get_server_from_url(url)

        url = servertools.normalize_url(servidor, url)

        if servidor == 'directo':
            new_server = servertools.corregir_other(url).lower()
            if new_server.startswith("http"):
                if not config.get_setting('developer_mode', default=False): return itemlist
            servidor = new_server

        itemlist.append(item.clone(server = servidor, url = url))

    return itemlist


def search(item, texto):
    logger.info()
    try:
        item.url = host + 'feeds/posts/summary?max-results=50&alt=json&q=' + texto.replace(" ", "+")
        return list_search(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
