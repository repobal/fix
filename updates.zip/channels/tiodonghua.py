# -*- coding: utf-8 -*-

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, servertools, jsontools, tmdb


host = 'https://tiodonghua.lat/'


def item_configurar_proxies(item):
    color_list_proxies = config.get_setting('channels_list_proxies_color', default='red')

    color_avis = config.get_setting('notification_avis_color', default='yellow')
    color_exec = config.get_setting('notification_exec_color', default='cyan')

    context = []

    tit = '[COLOR %s]Información proxies[/COLOR]' % color_avis
    context.append({'title': tit, 'channel': 'helper', 'action': 'show_help_proxies'})

    if config.get_setting('channel_tiodonghua_proxies', default=''):
        tit = '[COLOR %s][B]Quitar los proxies del canal[/B][/COLOR]' % color_list_proxies
        context.append({'title': tit, 'channel': item.channel, 'action': 'quitar_proxies'})

    tit = '[COLOR %s]Ajustes categoría proxies[/COLOR]' % color_exec
    context.append({'title': tit, 'channel': 'actions', 'action': 'open_settings'})

    plot = 'Es posible que para poder utilizar este canal necesites configurar algún proxy, ya que no es accesible desde algunos países/operadoras.'
    plot += '[CR]Si desde un navegador web no te funciona el sitio ' + host + ' necesitarás un proxy.'
    return item.clone( title = '[B]Configurar proxies a usar ...[/B]', action = 'configurar_proxies', folder=False, context=context, plot=plot, text_color='red' )

def quitar_proxies(item):
    from modules import submnuctext
    submnuctext._quitar_proxies(item)
    return True

def configurar_proxies(item):
    from core import proxytools
    return proxytools.configurar_proxies_canal(item.channel, host)


def do_downloadpage(url, post=None, headers=None):
    # ~ por si viene de enlaces guardados
    ant_hosts = ['https://tiodonghua.com/']

    for ant in ant_hosts:
        url = url.replace(ant, host)

    if not headers: headers = {'Referer': host}

    hay_proxies = False
    if config.get_setting('channel_tiodonghua_proxies', default=''): hay_proxies = True

    timeout = None
    if host in url:
        if hay_proxies: timeout = config.get_setting('channels_repeat', default=30)

    if not url.startswith(host):
        data = httptools.downloadpage(url, post=post, headers=headers, timeout=timeout).data
    else:
        if hay_proxies:
            data = httptools.downloadpage_proxy('tiodonghua', url, post=post, headers=headers, timeout=timeout).data
        else:
            data = httptools.downloadpage(url, post=post, headers=headers, timeout=timeout).data

        if not data:
            if not '/?s=' in url:
                if config.get_setting('channels_re_charges', default=True): platformtools.dialog_notification('TioDonghua', '[COLOR cyan]Re-Intentando acceso[/COLOR]')

                timeout = config.get_setting('channels_repeat', default=30)

                if hay_proxies:
                    data = httptools.downloadpage_proxy('tiodonghua', url, post=post, headers=headers, timeout=timeout).data
                else:
                    data = httptools.downloadpage(url, post=post, headers=headers, timeout=timeout).data

    if '<title>You are being redirected...</title>' in data or '<title>Just a moment...</title>' in data:
        if not '/?s=' in url:
            platformtools.dialog_notification(config.__addon_name, '[COLOR red][B]CloudFlare[COLOR orangered] Protection[/B][/COLOR]')
        return ''

    return data


def acciones(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( channel='submnuctext', action='_test_webs', title='Test Web del canal [COLOR yellow][B] ' + host + '[/B][/COLOR]',
                                from_channel='tiodonghua', folder=False, text_color='chartreuse' ))

    itemlist.append(item_configurar_proxies(item))

    itemlist.append(Item( channel='helper', action='show_help_tiodonghua', title='[COLOR aquamarine][B]Aviso[/COLOR] [COLOR green]Información[/B][/COLOR] canal', thumbnail=config.get_thumb('tiodonghua') ))

    platformtools.itemlist_refresh()

    return itemlist


def mainlist(item):
    return mainlist_animes(item)


def mainlist_animes(item):
    logger.info()
    itemlist = []

    if config.get_setting('descartar_anime', default=False): return

    if not config.get_setting('ses_pin'):
        if config.get_setting('adults_password'):
            from modules import actions
            if actions.adults_password(item) == False: return

        config.set_setting('ses_pin', True)

    itemlist.append(item.clone( action='acciones', title= '[B]Acciones[/B] [COLOR plum](si no hay resultados)[/COLOR]', text_color='goldenrod' ))

    itemlist.append(item.clone( title = 'Buscar anime ...', action = 'search', search_type = 'all', text_color='springgreen' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + 'explorar', search_type = 'tvshow' )) 

    itemlist.append(item.clone( title = 'Últimos episodios', action = 'last_epis', url = host, search_type = 'tvshow', text_color = 'cyan' ))

    itemlist.append(item.clone( title = 'En emisión', action = 'list_all', url = host + 'explorar?status=ongoing', search_type = 'tvshow' )) 

    itemlist.append(item.clone( title = 'Finalizados', action = 'list_all', url = host + 'explorar?status=completed', search_type = 'tvshow' )) 

    itemlist.append(item.clone( title = 'Más vistos', action = 'list_all', url = host + 'explorar?sort=popular', search_type = 'tvshow' )) 

    itemlist.append(item.clone( title = 'Más valorados', action = 'list_all', url = host + 'explorar?sort=rating', search_type = 'tvshow' )) 

    itemlist.append(item.clone( title = 'Películas', action = 'list_all', url = host + 'peliculas', group = 'pelis', search_type = 'movie', text_color = 'deepskyblue' ))

    itemlist.append(item.clone( title = 'Por género', action = 'generos',  search_type = 'tvshow' ))

    itemlist.append(item.clone( title = 'Por año', action = 'anios', search_type = 'tvshow' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(host + 'explorar')
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data, '>Géneros(.*?)</div></div></div></div>')

    matches = re.compile('<span>(.*?)</span>').findall(bloque)

    for title in matches:
        url = host + 'explorar?genres=' + title.lower()

        itemlist.append(item.clone( title = title, action = 'list_all', url=url, text_color='springgreen' ))

    return itemlist


def anios(item):
    logger.info()
    itemlist = []

    url_anio = host + 'explorar?year='

    from datetime import datetime
    current_year = int(datetime.today().year)

    for x in range(current_year, 2021, -1):
        url = url_anio + str(x)

        itemlist.append(item.clone( title = str(x), url = url, action = 'list_all', text_color='springgreen' ))

    itemlist.append(item.clone( title = 'Anteriores', url = host + 'explorar?year=before_2022', action = 'list_all', text_color='springgreen' ))

    return itemlist


def list_all(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    matches = scrapertools.find_multiple_matches(data, '<a class="group flex flex-col cursor-pointer"(.*?)</div></div></a>')

    for match in matches:
        url = scrapertools.find_single_match(match, 'href="(.*?)"')

        title = scrapertools.find_single_match(match, 'alt="(.*?)"')

        if not url or not title: continue

        thumb = scrapertools.find_single_match(match, 'src="(.*?)"')

        title = title.replace('Ver', '').replace('Online', '').replace('en HD', '').strip()

        title = title.replace('&#8217;s', "'s").replace('&#8211;', '').replace('&#8217;', '').replace('&#8220;', '').replace('&#8221;', '').replace('&#038;', '').strip()

        year = scrapertools.find_single_match(match, '</h3><span>(.*?)</span>')
        if ',' in year: year = year.split(",")[1].strip()

        if not year: year = '-'

        SerieName = corregir_SerieName(title)

        season = 1

        if '>T2' in match: season = 2
        elif '>T3' in match: season = 3
        elif '>T4' in match: season = 4
        elif '>T5' in match: season = 5
        elif '>T6' in match: season = 6
        elif '>T7' in match: season = 7
        elif '>T8' in match: season = 8
        elif '>T9' in match: season = 9

        elif '>S2' in match: season = 2
        elif '>S3' in match: season = 3
        elif '>S4' in match: season = 4
        elif '>S5' in match: season = 5
        elif '>S6' in match: season = 6
        elif '>S7' in match: season = 7
        elif '>S8' in match: season = 8
        elif '>S9' in match: season = 9

        elif 'Temporada 2' in match: season = 2
        elif 'Temporada 3' in match: season = 3
        elif 'Temporada 4' in match: season = 4
        elif 'Temporada 5' in match: season = 5
        elif 'Temporada 6' in match: season = 6
        elif 'Temporada 7' in match: season = 7
        elif 'Temporada 8' in match: season = 8
        elif 'Temporada 9' in match: season = 9

        url = host[:-1] + url

        if item.group == 'pelis':
            if not '/pelicula/' in url: continue

            titulo = title

            if 'Película Completa' in titulo: titulo = titulo.split("Película Completa")[0]
            if 'Sub Español' in titulo: titulo = titulo.split("Sub Español")[0]
            if '- Portada' in titulo: titulo = titulo.split("- Portada")[0]

            itemlist.append(item.clone( action = 'findvideos', url = url, title = title, thumbnail = thumb,
                                        contentType = 'movie', contentTitle = titulo, infoLabels = {'year': year} ))

        else:
            if not '/donghua/' in url: continue

            title = title.replace('Season', '[COLOR tan]Temp.[/COLOR]').replace('Temporada', '[COLOR tan]Temp.[/COLOR]')

            itemlist.append(item.clone( action = 'temporadas', url = url, title = title, thumbnail = thumb,
                                        infoLabels={'year': year},
                                        contentSerieName = SerieName, contentType = 'tvshow', contentSeason = season  ))

    tmdb.set_infoLabels(itemlist)

    if itemlist:
        next_page = ''

        if '<div class="pagination">' in data:
            next_page = scrapertools.find_single_match(data,'<div class="pagination">.*?<span class="current">.*?ref="(.*?)"')

            if next_page:
                if '/page/' in next_page:
                    itemlist.append(item.clone( title = 'Siguientes ...', action = 'list_all', url = next_page, text_color = 'coral' ))

        elif '<div class="hpage">' in data:
            if 'Previous' in data:
                next_page = scrapertools.find_single_match(data,'<div class="hpage">.*?Previous.*?ref="(.*?)"')
            else:
                next_page = scrapertools.find_single_match(data,'<div class="hpage">.*?ref="(.*?)"')

            if next_page:
                if '/page/' in next_page:
                    itemlist.append(item.clone( title = 'Siguientes ...', action = 'list_all', url = next_page, text_color = 'coral' ))

    return itemlist


def last_epis(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data, '>ÚLTIMOS EPISODIOS<(.*?)>PELÍCULAS DONGHUA<')

    matches = scrapertools.find_multiple_matches(bloque, '<a class="group flex flex-col cursor-pointer"(.*?)</div></div></a>')

    for match in matches:
        url = scrapertools.find_single_match(match, 'href="(.*?)"')

        title = scrapertools.find_single_match(match, 'alt="(.*?)"')

        if not url or not title: continue

        thumb = scrapertools.find_single_match(match, 'src="(.*?)"')

        title = title.replace('Ver', '').replace('Online', '').replace('en HD', '').replace(' HD', '').strip()

        title = title.replace('&#8217;s', "'s").replace('&#8211;', '').replace('&#8217;', '').replace('&#8220;', '').replace('&#8221;', '').replace('&#038;', '').strip()

        year = scrapertools.find_single_match(match, '</h3><span>(.*?)</span>')
        if ',' in year: year = year.split(",")[1].strip()

        if not year: year = '-'

        SerieName = corregir_SerieName(title)

        season = 1

        if '>T2' in match: season = 2
        elif '>T3' in match: season = 3
        elif '>T4' in match: season = 4
        elif '>T5' in match: season = 5
        elif '>T6' in match: season = 6
        elif '>T7' in match: season = 7
        elif '>T8' in match: season = 8
        elif '>T9' in match: season = 9

        elif '>S2' in match: season = 2
        elif '>S3' in match: season = 3
        elif '>S4' in match: season = 4
        elif '>S5' in match: season = 5
        elif '>S6' in match: season = 6
        elif '>S7' in match: season = 7
        elif '>S8' in match: season = 8
        elif '>S9' in match: season = 9

        elif 'Temporada 2' in match: season = 2
        elif 'Temporada 3' in match: season = 3
        elif 'Temporada 4' in match: season = 4
        elif 'Temporada 5' in match: season = 5
        elif 'Temporada 6' in match: season = 6
        elif 'Temporada 7' in match: season = 7
        elif 'Temporada 8' in match: season = 8
        elif 'Temporada 9' in match: season = 9

        epis = scrapertools.find_single_match(match, ">Capítulo(.*?)</div>")

        epis = epis.replace('<!-- -->', '').strip()

        if not epis: epis = 1

        title = title.replace('Season', '[COLOR tan]Temp.[/COLOR]').replace('season', '[COLOR tan]Temp.[/COLOR]')

        title = title.replace('Capítulo', '[COLOR goldenrod]Epis.[/COLOR]').replace('Capitulo', '[COLOR goldenrod]Epis.[/COLOR]')

        title = '[COLOR goldenrod]Epis.[/COLOR] ' + str(season) + 'x' + str(epis) + '  ' + title

        url = host[:-1] + url

        itemlist.append(item.clone( action = 'findvideos', url = url, title = title, thumbnail = thumb,
                                    infoLabels={'year': year},
                                    contentSerieName = SerieName, contentType = 'episode',
                                    contentSeason = season, contentEpisodeNumber = epis  ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def temporadas(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data, '>TEMPORADAS Y EPISODIOS<(.*?)$')

    temporadas = re.compile(">Temporada(.*?)<span", re.DOTALL).findall(bloque)

    for tempo in temporadas:
        if '&lt;' in tempo: tempo = tempo.split("&lt;")[0]

        tempo = tempo.replace('<!-- -->', '').strip()

        title = 'Temporada ' + tempo

        if len(temporadas) == 1:
            if config.get_setting('channels_seasons', default=True):
                platformtools.dialog_notification(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), 'solo [COLOR tan]' + title + '[/COLOR]')

                item.page = 0
                item.contentType = 'season'
                item.contentSeason = tempo
                itemlist = episodios(item)
                return itemlist

        itemlist.append(item.clone( action = 'episodios', title = title, contentType = 'season', contentSeason = tempo, page = 0, text_color = 'tan' ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def episodios(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0
    if not item.perpage: item.perpage = 50

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    matches = scrapertools.find_multiple_matches(data, '>Capítulo(.*?)</svg></div>')

    if item.page == 0 and item.perpage == 50:
        sum_parts = len(matches)

        try:
            tvdb_id = scrapertools.find_single_match(str(item), "'tvdb_id': '(.*?)'")
            if not tvdb_id: tvdb_id = scrapertools.find_single_match(str(item), "'tmdb_id': '(.*?)'")
        except: tvdb_id = ''

        if config.get_setting('channels_charges', default=True):
            item.perpage = sum_parts
            if sum_parts >= 100:
                platformtools.dialog_notification('TioDonghua', '[COLOR cyan]Cargando ' + str(sum_parts) + ' elementos[/COLOR]')
        elif tvdb_id:
            if sum_parts > 50:
                platformtools.dialog_notification('TioDonghua', '[COLOR cyan]Cargando Todos los elementos[/COLOR]')
                item.perpage = sum_parts
        else:
            item.perpage = sum_parts

            if sum_parts >= 1000:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]500[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('TioDonghua', '[COLOR cyan]Cargando 500 elementos[/COLOR]')
                    item.perpage = 500

            elif sum_parts >= 500:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]250[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('TioDonghua', '[COLOR cyan]Cargando 250 elementos[/COLOR]')
                    item.perpage = 250

            elif sum_parts >= 250:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]125[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('TioDonghua', '[COLOR cyan]Cargando 125 elementos[/COLOR]')
                    item.perpage = 125

            elif sum_parts >= 125:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]75[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('TioDonghua', '[COLOR cyan]Cargando 75 elementos[/COLOR]')
                    item.perpage = 75

            elif sum_parts > 50:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos [COLOR cyan][B]Todos[/B][/COLOR] de una sola vez ?'):
                    platformtools.dialog_notification('TioDonghua', '[COLOR cyan]Cargando ' + str(sum_parts) + ' elementos[/COLOR]')
                    item.perpage = sum_parts
                else: item.perpage = 50

    for match in matches[item.page * item.perpage:]:
        epis = scrapertools.find_single_match(match, "(.*?)</span>")

        epis = epis.replace('<!-- -->', '').strip()

        url = scrapertools.find_single_match(match, 'href="(.*?)"')

        url = host[:-1] + url

        titulo = '[COLOR goldenrod]Epis.[/COLOR] %sx%s  %s' % (str(item.contentSeason), str(epis), item.contentSerieName.replace('&#038;', '&'))

        itemlist.append(item.clone( action='findvideos', url = url, title = titulo,
                                    contentType = 'episode', contentSeason = item.contentSeason,
                                    contentEpisodeNumber = epis ))

        if len(itemlist) >= item.perpage:
            break

    if itemlist:
        if len(matches) > ((item.page + 1) * item.perpage):
            itemlist.append(item.clone( title="Siguientes ...", action="episodios", page = item.page + 1, perpage = item.perpage, text_color='coral' ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)

    data = data.replace('=\\', '="').replace('\\"', '"')

    matches1 = scrapertools.find_multiple_matches(data, '"embed_url":"(.*?)"')

    matches2 = scrapertools.find_multiple_matches(data, '"url":"(.*?)"')

    matches = matches1 + matches2

    ses = 0

    for match in matches:
        url = match.replace('\\/', '/')

        if not url: continue

        elif host in url: continue

        elif url == 'https://tiodonghua.lat': continue
        elif url == 'https://tiodonghua.playe': continue
        elif url == 'http': continue

        # ~ Multiserver
        ses += 1

        if '/nephobox.' in url: continue
        elif '.modagamers.' in url: continue
        elif 'cuyplay.com' in url: continue
        elif 'digitalxona.com' in url: continue
        elif 'animetemaefiore.club' in url: continue
        elif 'guccihide.com' in url: continue
        elif 'sharezweb.com' in url: continue
        elif 'videopress.com' in url: continue
        elif 'tioplayer.' in url: continue

        elif 'likessb.com' in url: continue
        elif '.animefenix.' in url: continue
        elif '/odysee.' in url: continue
        elif '/csst.online' in url: continue
        elif '.mediadelivery.' in url: continue
        elif '/csst.online' in url: continue

        if 'http:' in url: url = url.replace('http:', 'https:')

        if not 'https:' in url: url = 'https:' + url

        if url.startswith("https://sb"): continue
        elif 'fembed' in url or  'streamsb' in url or 'playersb' in url or 'fcom' in url or 'lvturbo' in url: continue

        url = url.replace('/Smoothpre.', '/smoothpre.')

        url = url.replace('/www.dailymotion.com/d/video/', '/geo.dailymotion.com/player.html?video=')

        servidor = servertools.get_server_from_url(url)

        if '/ok.ru' in url: servidor = 'okru'
        elif '/drive.' in url: servidor = 'gvideo'

        elif '/terabox.' in url:
            servidor = 'various'
            other = 'terabox'

        if servertools.is_server_available(servidor):
            if not servertools.is_server_enabled(servidor): continue
        else:
            if not config.get_setting('developer_mode', default=False): continue

        other = servidor

        if servidor == 'various': other = servertools.corregir_other(url)
        elif servidor == 'zures': other = servertools.corregir_zures(url)

        if servidor == other:
            if servidor == 'zures':
                if '/videa.' in url: other = 'Videa'
                else:
                    try: other = url.split("/")[2]
                    except: pass

                    other = other.replace('https:', '').strip()
                    other = other.replace('.to', '').replace('.cc', '').replace('.lol', '').replace('.online', '').replace('.site', '').replace('.biz', '').replace('.fit', '').replace('.art', '').replace('.com', '').strip()
            else: other = ''

        elif not servidor == 'directo':
           if not servidor in ['various', 'zures']: other = ''

        if servidor == 'directo':
            if config.get_setting('developer_mode', default=False):
                try: other = url.split("/")[2]
                except: pass

                other = other.replace('https:', '').strip()

        itemlist.append(Item( channel = item.channel, action = 'play', server = servidor, url = url,
                              language = 'Vose', other = other.capitalize() ))

    if not itemlist:
        if not ses == 0:
            platformtools.dialog_notification(config.__addon_name, '[COLOR tan][B]Sin enlaces Soportados[/B][/COLOR]')
            return

    return itemlist


def list_search(item): 
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    jdata = jsontools.load(data)

    for vid in jdata["data"]:
        url = vid["slug"]
        title = vid["title"]
        thumb = vid["poster_url"]

        year = vid["release_year"]

        url = host + 'donghua/' + url

        tipo = 'tvshow' if "'type': 'donghua'" in str(vid) else 'movie'
        sufijo = '' if item.search_type != 'all' else tipo

        if tipo == 'movie':
            itemlist.append(item.clone( action = 'findvideos', url = url, title = title, thumbnail = thumb,
                                        fmt_sufijo=sufijo,
                                        contentType = 'movie', contentTitle = title, infoLabels = {'year': year} ))
        else:
            title = title.replace('Season', '[COLOR tan]Temp.[/COLOR]').replace('Temporada', '[COLOR tan]Temp.[/COLOR]')

            itemlist.append(item.clone( action = 'temporadas', url = url, title = title, thumbnail = thumb,
                                        fmt_sufijo=sufijo,
                                        contentType = 'tvshow', contentSerieName = title,
                                        infoLabels={'year': year} ))


    tmdb.set_infoLabels(itemlist)

    return itemlist


def corregir_SerieName(SerieName):
    logger.info()

    SerieName = SerieName.replace('Novela', '').strip()

    if 'Sub Español' in SerieName: SerieName = SerieName.split("Sub Español")[0]
    if 'Traducida al Español' in SerieName: SerieName = SerieName.split("Traducida al Español")[0]
    if 'Legendado Portugués' in SerieName: SerieName = SerieName.split("Legendado Portugués")[0]
    if 'Portugués' in SerieName: SerieName = SerieName.split("Portugués")[0]

    if 'Season' in SerieName: SerieName = SerieName.split("Season")[0]
    if 'season' in SerieName: SerieName = SerieName.split("season")[0]

    if 'Temporada' in SerieName: SerieName = SerieName.split("Temporada")[0]
    if 'temporada' in SerieName: SerieName = SerieName.split("temporada")[0]

    if 'Movie' in SerieName: SerieName = SerieName.split("Movie")[0]

    if '(TV)' in SerieName: SerieName = SerieName.split("(TV)")[0]

    if 'Episodio' in SerieName: SerieName = SerieName.split("Episodio")[0]
    if 'Capítulo' in SerieName: SerieName = SerieName.split("Capítulo")[0]
    if 'Capitulo' in SerieName: SerieName = SerieName.split("Capitulo")[0]

    if '- Portada Oficial' in SerieName: SerieName = SerieName.split("- Portada Oficial")[0]

    if ' S1 ' in SerieName: SerieName = SerieName.split(" S1 ")[0]
    elif ' S2 ' in SerieName: SerieName = SerieName.split(" S2 ")[0]
    elif ' S3 ' in SerieName: SerieName = SerieName.split(" S3 ")[0]
    elif ' S4 ' in SerieName: SerieName = SerieName.split(" S4 ")[0]
    elif ' S5 ' in SerieName: SerieName = SerieName.split(" S5 ")[0]
    elif ' S6 ' in SerieName: SerieName = SerieName.split(" S6 ")[0]
    elif ' S7 ' in SerieName: SerieName = SerieName.split(" S7 ")[0]
    elif ' S8 ' in SerieName: SerieName = SerieName.split(" S8 ")[0]
    elif ' S9 ' in SerieName: SerieName = SerieName.split(" S9 ")[0]

    if ' T1 ' in SerieName: SerieName = SerieName.split(" T1 ")[0]
    elif ' T2 ' in SerieName: SerieName = SerieName.split(" T2 ")[0]
    elif ' T3 ' in SerieName: SerieName = SerieName.split(" T3 ")[0]
    elif ' T4 ' in SerieName: SerieName = SerieName.split(" T4 ")[0]
    elif ' T5 ' in SerieName: SerieName = SerieName.split(" T5 ")[0]
    elif ' T6 ' in SerieName: SerieName = SerieName.split(" T6 ")[0]
    elif ' T7 ' in SerieName: SerieName = SerieName.split(" T7 ")[0]
    elif ' T8 ' in SerieName: SerieName = SerieName.split(" T8 ")[0]
    elif ' T9 ' in SerieName: SerieName = SerieName.split(" T9 ")[0]

    if '2nd' in SerieName: SerieName = SerieName.split("2nd")[0]
    elif '3rd' in SerieName: SerieName = SerieName.split("3rd")[0]
    elif '4th' in SerieName: SerieName = SerieName.split("4th")[0]
    elif '5th' in SerieName: SerieName = SerieName.split("5th")[0]
    elif '6th' in SerieName: SerieName = SerieName.split("6th")[0]
    elif '7th' in SerieName: SerieName = SerieName.split("7th")[0]
    elif '8th' in SerieName: SerieName = SerieName.split("8th")[0]
    elif '9th' in SerieName: SerieName = SerieName.split("9th")[0]

    SerieName = SerieName.strip()

    return SerieName


def _epis(item):
    logger.info()

    item.url = host
    item.search_type = 'tvshow'

    return last_epis(item)


def search(item, texto):
    logger.info()
    try:
        item.url = 'https://tioplayer.cloudlatino.com/api/v1/search?q=' + texto.replace(" ", "+")
        return list_search(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
