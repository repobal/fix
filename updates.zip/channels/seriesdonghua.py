# -*- coding: utf-8 -*-

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, servertools, jsontools, tmdb


host = 'https://seriesdonghua.com/'


def do_downloadpage(url, post=None, headers=None):
    if not headers: headers = {'Referer': host}

    data = httptools.downloadpage(url, post=post, headers=headers).data

    return data


def mainlist(item):
    return mainlist_animes(item)


def mainlist_animes(item):
    logger.info()
    itemlist = []

    if config.get_setting('descartar_anime', default=False): return

    if not config.get_setting('ses_pin'):
        if config.get_setting('adults_password'):
            from modules import actions
            if actions.adults_password(item) == False: return

        config.set_setting('ses_pin', True)

    itemlist.append(item.clone( title = 'Buscar anime ...', action = 'search', search_type = 'all', text_color='springgreen' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + 'todos-los-donghuas', search_type = 'tvshow' )) 

    itemlist.append(item.clone( title = 'Últimos episodios', action = 'last_epis', url = host, search_type = 'tvshow', text_color = 'cyan' ))

    itemlist.append(item.clone( title = 'En emisión', action = 'list_all', url = host + 'donghuas-en-emision', search_type = 'tvshow' )) 

    itemlist.append(item.clone( title = 'Finalizados', action = 'list_all', url = host + 'donghuas-finalizados', search_type = 'tvshow' )) 

    itemlist.append(item.clone( title = 'Por género', action = 'generos',  search_type = 'tvshow' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(host)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data, 'Géneros & Categorías(.*?)</div></div>')

    matches = re.compile('<a href="(.*?)".*?title="(.*?)"').findall(bloque)

    for url, title in matches:
        url = host[:-1] + url

        title = title.replace('Donghuas de', '').replace('Sub Español', '').strip()

        itemlist.append(item.clone( title = title, action = 'list_all', url=url, text_color='springgreen' ))

    return itemlist


def list_all(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    matches = scrapertools.find_multiple_matches(data, '<article(.*?)</article>')

    for match in matches:
        url = scrapertools.find_single_match(match, 'href="(.*?)"')

        title = scrapertools.find_single_match(match, 'alt="(.*?)"')

        if not url or not title: continue

        thumb = scrapertools.find_single_match(match, 'src="(.*?)"')

        title = title.replace('Donghua', '').strip()

        title = title.replace('&#8217;s', "'s").replace('&#8211;', '').replace('&#8217;', '').replace('&#8220;', '').replace('&#8221;', '').replace('&#038;', '').strip()

        SerieName = corregir_SerieName(title)

        season = 1

        if '>T2' in match: season = 2
        elif '>T3' in match: season = 3
        elif '>T4' in match: season = 4
        elif '>T5' in match: season = 5
        elif '>T6' in match: season = 6
        elif '>T7' in match: season = 7
        elif '>T8' in match: season = 8
        elif '>T9' in match: season = 9

        elif '>S2' in match: season = 2
        elif '>S3' in match: season = 3
        elif '>S4' in match: season = 4
        elif '>S5' in match: season = 5
        elif '>S6' in match: season = 6
        elif '>S7' in match: season = 7
        elif '>S8' in match: season = 8
        elif '>S9' in match: season = 9

        elif 'Temporada 2' in match: season = 2
        elif 'Temporada 3' in match: season = 3
        elif 'Temporada 4' in match: season = 4
        elif 'Temporada 5' in match: season = 5
        elif 'Temporada 6' in match: season = 6
        elif 'Temporada 7' in match: season = 7
        elif 'Temporada 8' in match: season = 8
        elif 'Temporada 9' in match: season = 9

        url = host[:-1] + url

        title = title.replace('Season', '[COLOR tan]Temp.[/COLOR]').replace('Temporada', '[COLOR tan]Temp.[/COLOR]')

        itemlist.append(item.clone( action = 'temporadas', url = url, title = title, thumbnail = thumb,
                                    infoLabels={'year': '-'},
                                    contentSerieName = SerieName, contentType = 'tvshow', contentSeason = season  ))

    tmdb.set_infoLabels(itemlist)

    if itemlist:
        next_page = ''

        if '<ul class="pagination">' in data:
            next_page = scrapertools.find_single_match(data,'<ul class="pagination">.*?<li class="page-item active".*?href="(.*?)"')

            if next_page:
                if '?page=' in next_page:
                    itemlist.append(item.clone( title = 'Siguientes ...', action = 'list_all', url = next_page, text_color = 'coral' ))

    return itemlist


def last_epis(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data, 'Nuevos Episodios<(.*?)Series Donghua en Emisión<')

    matches = scrapertools.find_multiple_matches(bloque, '<article(.*?)</article>')

    for match in matches:
        url = scrapertools.find_single_match(match, 'href="(.*?)"')

        title = scrapertools.find_single_match(match, 'title="(.*?)"')

        if not url or not title: continue

        thumb = scrapertools.find_single_match(match, 'src="(.*?)"')

        thumb = host[:-1] + thumb

        title = title.replace('&#8217;s', "'s").replace('&#8211;', '').replace('&#8217;', '').replace('&#8220;', '').replace('&#8221;', '').replace('&#038;', '').strip()

        SerieName = corregir_SerieName(title)

        season = 1

        if '>T2' in match: season = 2
        elif '>T3' in match: season = 3
        elif '>T4' in match: season = 4
        elif '>T5' in match: season = 5
        elif '>T6' in match: season = 6
        elif '>T7' in match: season = 7
        elif '>T8' in match: season = 8
        elif '>T9' in match: season = 9

        elif '>S2' in match: season = 2
        elif '>S3' in match: season = 3
        elif '>S4' in match: season = 4
        elif '>S5' in match: season = 5
        elif '>S6' in match: season = 6
        elif '>S7' in match: season = 7
        elif '>S8' in match: season = 8
        elif '>S9' in match: season = 9

        elif 'Temporada 2' in match: season = 2
        elif 'Temporada 3' in match: season = 3
        elif 'Temporada 4' in match: season = 4
        elif 'Temporada 5' in match: season = 5
        elif 'Temporada 6' in match: season = 6
        elif 'Temporada 7' in match: season = 7
        elif 'Temporada 8' in match: season = 8
        elif 'Temporada 9' in match: season = 9

        epis = scrapertools.find_single_match(match, '<span class="badge-tag badge-ep">EP(.*?)</span>').strip()

        if not epis: epis = 1

        title = title.replace('Season', '[COLOR tan]Temp.[/COLOR]').replace('season', '[COLOR tan]Temp.[/COLOR]')

        title = title.replace('Capítulo', '[COLOR goldenrod]Epis.[/COLOR]').replace('Capitulo', '[COLOR goldenrod]Epis.[/COLOR]').replace('Episodio', '[COLOR goldenrod]Epis.[/COLOR]')

        title = '[COLOR goldenrod]Epis.[/COLOR] ' + str(season) + 'x' + str(epis) + '  ' + title

        url = host[:-1] + url

        itemlist.append(item.clone( action = 'findvideos', url = url, title = title, thumbnail = thumb,
                                    infoLabels={'year': '-'},
                                    contentSerieName = SerieName, contentType = 'episode',
                                    contentSeason = season, contentEpisodeNumber = epis  ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def temporadas(item):
    logger.info()
    itemlist = []

    if config.get_setting('channels_seasons', default=True):
        platformtools.dialog_notification(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), 'sin [COLOR tan]Temporadas[/COLOR]')

    item.page = 0
    item.contentType = 'season'
    item.contentSeason = 1
    itemlist = episodios(item)

    return itemlist


def episodios(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0
    if not item.perpage: item.perpage = 50

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data, '<div class="episodes-list-mode"(.*?)</section>')

    matches = scrapertools.find_multiple_matches(bloque, '<article(.*?)</article>')

    if item.page == 0 and item.perpage == 50:
        sum_parts = len(matches)

        try:
            tvdb_id = scrapertools.find_single_match(str(item), "'tvdb_id': '(.*?)'")
            if not tvdb_id: tvdb_id = scrapertools.find_single_match(str(item), "'tmdb_id': '(.*?)'")
        except: tvdb_id = ''

        if config.get_setting('channels_charges', default=True):
            item.perpage = sum_parts
            if sum_parts >= 100:
                platformtools.dialog_notification('SeriesDonghua', '[COLOR cyan]Cargando ' + str(sum_parts) + ' elementos[/COLOR]')
        elif tvdb_id:
            if sum_parts > 50:
                platformtools.dialog_notification('SeriesDonghua', '[COLOR cyan]Cargando Todos los elementos[/COLOR]')
                item.perpage = sum_parts
        else:
            item.perpage = sum_parts

            if sum_parts >= 1000:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]500[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('SeriesDonghua', '[COLOR cyan]Cargando 500 elementos[/COLOR]')
                    item.perpage = 500

            elif sum_parts >= 500:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]250[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('SeriesDonghua', '[COLOR cyan]Cargando 250 elementos[/COLOR]')
                    item.perpage = 250

            elif sum_parts >= 250:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]125[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('SeriesDonghua', '[COLOR cyan]Cargando 125 elementos[/COLOR]')
                    item.perpage = 125

            elif sum_parts >= 125:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]75[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('SeriesDonghua', '[COLOR cyan]Cargando 75 elementos[/COLOR]')
                    item.perpage = 75

            elif sum_parts > 50:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos [COLOR cyan][B]Todos[/B][/COLOR] de una sola vez ?'):
                    platformtools.dialog_notification('SeriesDonghua', '[COLOR cyan]Cargando ' + str(sum_parts) + ' elementos[/COLOR]')
                    item.perpage = sum_parts
                else: item.perpage = 50

    for match in matches[item.page * item.perpage:]:
        epis = scrapertools.find_single_match(match, 'data-ep="(.*?)"')

        if not epis: epis = 1

        url = scrapertools.find_single_match(match, 'href="(.*?)"')

        url = host[:-1] + url

        titulo = '[COLOR goldenrod]Epis.[/COLOR] %s  %s' % (str(epis), item.contentSerieName.replace('&#038;', '&'))

        itemlist.append(item.clone( action='findvideos', url = url, title = titulo,
                                    contentType = 'episode', contentSeason = item.contentSeason,
                                    contentEpisodeNumber = epis ))

        if len(itemlist) >= item.perpage:
            break

    if itemlist:
        if len(matches) > ((item.page + 1) * item.perpage):
            itemlist.append(item.clone( title="Siguientes ...", action="episodios", page = item.page + 1, perpage = item.perpage, text_color='coral' ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    if not item.perpage: item.perpage = 50

    _token  = scrapertools.find_single_match(data, 'name="_token" value="(.*?)"')

    if not _token: return itemlist

    bloque = scrapertools.find_single_match(data, '<div class="server-tabs-bar">(.*?)</div>')

    matches = scrapertools.find_multiple_matches(data, '<button(.*?)</button>')

    ses = 0

    for match in matches:
        ses += 1

        _id = scrapertools.find_single_match(match, 'data-video-id="(.*?)"')

        _index = scrapertools.find_single_match(match, 'data-server-index="(.*?)"')

        if not _id or not _index: continue

        srv = scrapertools.find_single_match(match, '<span>(.*?)<span>').lower()

        post = '{\"video_id\": "%s", \"server_index\": %s, \"unescape\": "False"}' % (_id, _index)

        headers = {'Referer': item.url, 'Content-Type': 'application/json', 'X-CSRF-TOKEN': _token, 'X-Requested-With': 'XMLHttpRequest'}

        datap = do_downloadpage(host + 'api/player/get-server', post = post, headers = headers)

        url = scrapertools.find_single_match(datap, '"embed_url":"(.*?)"')

        if not url: continue

        url = url.replace('\\/', '/')

        if url.startswith("https://sb"): continue
        elif 'fembed' in url or  'streamsb' in url or 'playersb' in url or 'fcom' in url or 'lvturbo' in url: continue

        url = url.replace('/www.dailymotion.com/d/video/', '/geo.dailymotion.com/player.html?video=')

        servidor = servertools.get_server_from_url(url)

        if '/ok.ru' in url: servidor = 'okru'

        if servertools.is_server_available(servidor):
            if not servertools.is_server_enabled(servidor): continue
        else:
            if not config.get_setting('developer_mode', default=False): continue

        other = servidor

        if servidor == 'various': other = servertools.corregir_other(url)
        elif servidor == 'zures': other = servertools.corregir_zures(url)

        elif not servidor == 'directo':
           if not servidor in ['various', 'zures']: other = ''

        if servidor == 'directo':
            if config.get_setting('developer_mode', default=False):
                try: other = url.split("/")[2]
                except: pass

                other = srv

        itemlist.append(Item( channel = item.channel, action = 'play', server = servidor, url = url,
                              language = 'Vose', other = other.capitalize() ))

    if not itemlist:
        if not ses == 0:
            platformtools.dialog_notification(config.__addon_name, '[COLOR tan][B]Sin enlaces Soportados[/B][/COLOR]')
            return

    return itemlist


def corregir_SerieName(SerieName):
    logger.info()

    SerieName = SerieName.replace('Novela', '').strip()

    if 'Sub Español' in SerieName: SerieName = SerieName.split("Sub Español")[0]
    if 'Traducida al Español' in SerieName: SerieName = SerieName.split("Traducida al Español")[0]
    if 'Legendado Portugués' in SerieName: SerieName = SerieName.split("Legendado Portugués")[0]
    if 'Portugués' in SerieName: SerieName = SerieName.split("Portugués")[0]

    if 'Season' in SerieName: SerieName = SerieName.split("Season")[0]
    if 'season' in SerieName: SerieName = SerieName.split("season")[0]

    if 'Temporada' in SerieName: SerieName = SerieName.split("Temporada")[0]
    if 'temporada' in SerieName: SerieName = SerieName.split("temporada")[0]

    if 'Movie' in SerieName: SerieName = SerieName.split("Movie")[0]

    if '(TV)' in SerieName: SerieName = SerieName.split("(TV)")[0]

    if 'Episodio' in SerieName: SerieName = SerieName.split("Episodio")[0]
    if 'Capítulo' in SerieName: SerieName = SerieName.split("Capítulo")[0]
    if 'Capitulo' in SerieName: SerieName = SerieName.split("Capitulo")[0]

    if '- Portada Oficial' in SerieName: SerieName = SerieName.split("- Portada Oficial")[0]

    if ' S1 ' in SerieName: SerieName = SerieName.split(" S1 ")[0]
    elif ' S2 ' in SerieName: SerieName = SerieName.split(" S2 ")[0]
    elif ' S3 ' in SerieName: SerieName = SerieName.split(" S3 ")[0]
    elif ' S4 ' in SerieName: SerieName = SerieName.split(" S4 ")[0]
    elif ' S5 ' in SerieName: SerieName = SerieName.split(" S5 ")[0]
    elif ' S6 ' in SerieName: SerieName = SerieName.split(" S6 ")[0]
    elif ' S7 ' in SerieName: SerieName = SerieName.split(" S7 ")[0]
    elif ' S8 ' in SerieName: SerieName = SerieName.split(" S8 ")[0]
    elif ' S9 ' in SerieName: SerieName = SerieName.split(" S9 ")[0]

    if ' T1 ' in SerieName: SerieName = SerieName.split(" T1 ")[0]
    elif ' T2 ' in SerieName: SerieName = SerieName.split(" T2 ")[0]
    elif ' T3 ' in SerieName: SerieName = SerieName.split(" T3 ")[0]
    elif ' T4 ' in SerieName: SerieName = SerieName.split(" T4 ")[0]
    elif ' T5 ' in SerieName: SerieName = SerieName.split(" T5 ")[0]
    elif ' T6 ' in SerieName: SerieName = SerieName.split(" T6 ")[0]
    elif ' T7 ' in SerieName: SerieName = SerieName.split(" T7 ")[0]
    elif ' T8 ' in SerieName: SerieName = SerieName.split(" T8 ")[0]
    elif ' T9 ' in SerieName: SerieName = SerieName.split(" T9 ")[0]

    if '2nd' in SerieName: SerieName = SerieName.split("2nd")[0]
    elif '3rd' in SerieName: SerieName = SerieName.split("3rd")[0]
    elif '4th' in SerieName: SerieName = SerieName.split("4th")[0]
    elif '5th' in SerieName: SerieName = SerieName.split("5th")[0]
    elif '6th' in SerieName: SerieName = SerieName.split("6th")[0]
    elif '7th' in SerieName: SerieName = SerieName.split("7th")[0]
    elif '8th' in SerieName: SerieName = SerieName.split("8th")[0]
    elif '9th' in SerieName: SerieName = SerieName.split("9th")[0]

    SerieName = SerieName.strip()

    return SerieName


def _epis(item):
    logger.info()

    item.url = host
    item.search_type = 'tvshow'

    return last_epis(item)


def search(item, texto):
    logger.info()
    try:
        item.url = host + 'buscar.php?s=' + texto.replace(" ", "+")
        return list_all(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
