# -*- coding: utf-8 -*-

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, servertools, jsontools, tmdb


host = 'https://areshd.com/'


def do_downloadpage(url, post=None, headers=None):
    data = httptools.downloadpage(url, post=post, headers=headers).data

    return data


def mainlist(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar ...', action = 'search', search_type = 'all', text_color = 'yellow' ))

    itemlist.append(item.clone( title = 'Películas', action = 'mainlist_pelis', text_color = 'deepskyblue' ))
    itemlist.append(item.clone( title = 'Series', action = 'mainlist_series', text_color = 'hotpink' ))

    return itemlist


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie', text_color = 'deepskyblue' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + '_next/data/w7jD9bO9T53W11riRVYei/es/peliculas/pagina/', search_type = 'movie' ))

    itemlist.append(item.clone( title = 'Por género', action = 'generos', search_type = 'movie' ))

    return itemlist


def mainlist_series(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar serie ...', action = 'search', search_type = 'tvshow', text_color = 'hotpink' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + '_next/data/w7jD9bO9T53W11riRVYei/es/series/pagina/', search_type = 'tvshow' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(host)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data, '>Generos<(.*?)</ul>')

    matches = re.compile('<a href="([^"]+)">([^<]+)').findall(bloque)

    for url, title in matches:
        url = host[:-1] + url

        itemlist.append(item.clone( title = title.capitalize(), action = 'list_gen', url = url, text_color = 'deepskyblue' ))

    if itemlist:
        itemlist.append(item.clone( title = 'Documental', action = 'list_gen', url = host + 'genero/documental', text_color = 'deepskyblue' ))
        itemlist.append(item.clone( title = 'Western', action = 'list_gen', url = host + 'genero/western', text_color = 'deepskyblue' ))

    return sorted(itemlist,key=lambda x: x.title)


def list_all(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 1

    _url = item.url + str(item.page) + '.json?page=' + str(item.page)

    data = do_downloadpage(_url)

    # ~ la primera pagina no da el TOTAL
    new_url = ''

    if str(item.page) == '1':
        if '/series/pagina/' in item.url:
            new_url = item.url.split("pagina/")[0]
            new_url = new_url + '.json'

            data = do_downloadpage(new_url)

    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    jdata = jsontools.load(data)

    bloque = scrapertools.find_single_match(str(jdata), "(.*?)'pages':")

    bloque = bloque.replace('}}]', '}},')

    matches = scrapertools.find_multiple_matches(str(bloque), "{'titles': {'name':(.*?)}},")

    for match in matches:
        match = match.strip()

        title = scrapertools.find_single_match(str(match), "'(.*?)'")
        title = title.replace('"},', '')

        url = scrapertools.find_single_match(str(match), "'url': {'slug': '(.*?)'")

        if not url or not title: continue

        _name = scrapertools.find_single_match(str(match), "'slug': {'name': '(.*?)'")

        if not _name: continue

        thumb = scrapertools.find_single_match(str(match), "{'poster': '(.*?)'")

        year = scrapertools.find_single_match(str(match), "'releaseDate': '(.*?)-")
        if not year: year = '-'

        plot = scrapertools.find_single_match(str(match), "'overview': '(.*?)'")

        tipo = 'movie' if 'movies/' in url else 'tvshow'

        if tipo == 'movie':
            if not item.search_type == "all":
                if item.search_type == "tvshow": continue

            _peli = host + 'pelicula/' + _name

            itemlist.append(item.clone( action='findvideos', url=_peli, title=title, thumbnail=thumb,
                                        contentType = 'movie', contentTitle = title, infoLabels={'year': year, 'plot': plot} ))

        if tipo == 'tvshow':
            if not item.search_type == "all":
                if item.search_type == "movie": continue

            _serie = host + 'serie/' + _name

            itemlist.append(item.clone( action='temporadas', url=_serie, title=title, thumbnail=thumb,
                                        contentType = 'tvshow', contentSerieName = title, infoLabels={'year': year} ))

    tmdb.set_infoLabels(itemlist)

    if itemlist:
        if "'pages':" in str(jdata):
            last = scrapertools.find_single_match(str(jdata), "'pages':(.*?)},").strip()

            if last:
                if "," in last: last = scrapertools.find_single_match(last, "(.*?),").strip()

                try: last = int(last)
                except: last = ''

            if not new_url: act_url = item.url.split("/pagina/")[0]
            else: act_url = scrapertools.find_single_match(_url, "(.*?)/pagina/")

            if act_url:
                next_page = act_url + '/pagina/'

                new_page = item.page + 1

                if last:
                    if new_page <= last:
                        itemlist.append(item.clone( title = 'Siguientes ...', url = next_page, page = new_page,
                                                    action='list_all', text_color = 'coral' ))

    return itemlist


def list_gen(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data,'>Peliculas<(.*?)>Copyright')

    matches = re.compile('<a class="Posters-link"(.*?)</div></div></div>', re.DOTALL).findall(bloque)

    for article in matches:
        title = scrapertools.find_single_match(article, '<img alt="(.*?)"')

        url = scrapertools.find_single_match(article, 'href="(.*?)"')

        if not url or not title: continue

        thumb = scrapertools.find_single_match(article, 'src="(.*?)"')

        thumb = host[:1] + thumb.replace('&amp;', '&')

        url = host[:-1] + url

        itemlist.append(item.clone( action='findvideos', url=url, title=title, thumbnail=thumb,
                                    contentType='movie', contentTitle=title, infoLabels={'year': '-'} ))

    tmdb.set_infoLabels(itemlist)

    if itemlist:
        if '<div class="nav-links">' in data:
            next_page = scrapertools.find_single_match(data, '<div class="nav-links">.*?<span class="page-link current">.*?<a href="(.*?)".*?</nav>')

            if next_page:
                if '/pagina/' in next_page:
                    next_page = host[:-1] + next_page
                    itemlist.append(item.clone( title = 'Siguientes ...', url = next_page, action = 'list_gen', text_color='coral' ))

    return itemlist


def temporadas(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)

    temporadas = re.compile('data-toggle="tab">.*?<!-- -->(.*?)<!-- -->', re.DOTALL).findall(data)

    for tempo in temporadas:
        title = 'Temporada ' + tempo

        if tempo == '0':
            if config.get_setting('channels_especiales', default=True): continue

        if len(temporadas) == 1:
            if config.get_setting('channels_seasons', default=True):
                platformtools.dialog_notification(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), 'solo [COLOR tan]' + title + '[/COLOR]')

                item.page = 0
                item.contentType = 'season'
                item.contentSeason = tempo
                itemlist = episodios(item)
                return itemlist

        itemlist.append(item.clone( action = 'episodios', title = title, page = 0, contentType = 'season', contentSeason = tempo, text_color = 'tan' ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def episodios(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0
    if not item.perpage: item.perpage = 50

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    block = scrapertools.find_single_match(str(data), '"seasons"(.*?)"titles"')

    if not block: return itemlist

    bloque = scrapertools.find_single_match(str(block), '{"number":' + str(item.contentSeason) + '.*?"episodes"(.*?)}]}')

    matches = re.compile('"title":"(.*?)".*?"number":(.*?),.*?"image":"(.*?)".*?"slug":"(.*?)"', re.DOTALL).findall(str(bloque))

    if item.page == 0 and item.perpage == 50:
        sum_parts = len(matches)

        try:
            tvdb_id = scrapertools.find_single_match(str(item), "'tvdb_id': '(.*?)'")
            if not tvdb_id: tvdb_id = scrapertools.find_single_match(str(item), "'tmdb_id': '(.*?)'")
        except: tvdb_id = ''

        if config.get_setting('channels_charges', default=True):
            item.perpage = sum_parts
            if sum_parts >= 100:
                platformtools.dialog_notification('AresHd', '[COLOR cyan]Cargando ' + str(sum_parts) + ' elementos[/COLOR]')
        elif tvdb_id:
            if sum_parts > 50:
                platformtools.dialog_notification('AresHd', '[COLOR cyan]Cargando Todos los elementos[/COLOR]')
                item.perpage = sum_parts
        else:
            item.perpage = sum_parts

            if sum_parts >= 1000:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]500[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('AresHd', '[COLOR cyan]Cargando 500 elementos[/COLOR]')
                    item.perpage = 500

            elif sum_parts >= 500:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]250[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('AresHd', '[COLOR cyan]Cargando 250 elementos[/COLOR]')
                    item.perpage = 250

            elif sum_parts >= 250:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]125[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('AresHd', '[COLOR cyan]Cargando 125 elementos[/COLOR]')
                    item.perpage = 125

            elif sum_parts >= 125:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]75[/B][/COLOR] elementos ?'):
                    platformtools.dialog_notification('AresHd', '[COLOR cyan]Cargando 75 elementos[/COLOR]')
                    item.perpage = 75

            elif sum_parts > 50:
                if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos [COLOR cyan][B]Todos[/B][/COLOR] de una sola vez ?'):
                    platformtools.dialog_notification('AresHd', '[COLOR cyan]Cargando ' + str(sum_parts) + ' elementos[/COLOR]')
                    item.perpage = sum_parts
                else: item.perpage = 50

    for title, epis, thumb, url in matches[item.page * item.perpage:]:
        name = scrapertools.find_single_match(url, '/.*?/(.*?)/')

        url = host + 'episodio/' + name + '-temporada-' + str(item.contentSeason) + '-episodio-' + epis

        titulo = str(item.contentSeason) + 'x' + str(epis) + ' ' + title.replace(str(item.contentSeason) + 'x' + str(epis), '').strip()

        titulo = titulo.replace('Episode', '[COLOR goldenrod]Epis.[/COLOR]').replace('episode', '[COLOR goldenrod]Epis.[/COLOR]')
        titulo = titulo.replace('Episodio', '[COLOR goldenrod]Epis.[/COLOR]').replace('episodio', '[COLOR goldenrod]Epis.[/COLOR]')
        titulo = titulo.replace('Capítulo', '[COLOR goldenrod]Epis.[/COLOR]').replace('capítulo', '[COLOR goldenrod]Epis.[/COLOR]').replace('Capitulo', '[COLOR goldenrod]Epis.[/COLOR]').replace('capitulo', '[COLOR goldenrod]Epis.[/COLOR]')

        itemlist.append(item.clone( action='findvideos', url = url, title = titulo, thumbnail=thumb,
                                    contentType = 'episode', contentSeason = item.contentSeason, contentEpisodeNumber=epis ))

        if len(itemlist) >= item.perpage:
            break

    tmdb.set_infoLabels(itemlist)

    if itemlist:
        if len(matches) > ((item.page + 1) * item.perpage):
            itemlist.append(item.clone( title="Siguientes ...", action="episodios", page = item.page + 1, perpage = item.perpage, text_color='coral' ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)

    block = scrapertools.find_single_match(data, '<div class="player"><div class="VideoPlayer Bglg">(.*?)</ul></div>')

    if not block: return itemlist

    idiomas = scrapertools.find_multiple_matches(block, '<li class="pres"><a class="playr">(.*?)</a></li>')

    bloques = scrapertools.find_multiple_matches(data, '<ul class="TbVideoNv nav nav-tabs hide" role="tablist">(.*?)</ul>')

    ses = 0

    i = 0

    for bloque in bloques:
         matches = scrapertools.find_multiple_matches(bloque, '<li class="pres" data-tr="(.*?)".*?a class="playr">(.*?)</a>')

         for link, srv in matches:
             ses += 1

             if 'youtube' in srv: continue

             if i == 0: lang = idiomas[0]
             elif i == 1: lang = idiomas[1]
             elif i == 2: lang = idiomas[2]
             else: lang =''

             if 'Latino' in lang: lang = 'Lat'
             elif 'Castellano' in lang or 'Español' in lang: lang = 'Esp'
             elif 'Subtitulado' in lang or 'VOSE' in lang: lang = 'Vose'
             else: lang = '?'

             srv = srv.lower().strip()

             servidor = servertools.corregir_servidor(srv)

             other = srv

             if other == 'plustream': continue

             if servidor == srv: other = ''
             elif not servidor == 'directo':
                if not servidor == 'various': other = ''

             itemlist.append(Item( channel = item.channel, action = 'play', server = servidor, title = '', url = link,
                                   language = lang, other = other.capitalize() ))

         i += 1

    if not itemlist:
        if not ses == 0:
            platformtools.dialog_notification(config.__addon_name, '[COLOR tan][B]Sin enlaces Soportados[/B][/COLOR]')
            return

    return itemlist


def play(item):
    logger.info()
    itemlist = []

    url = item.url

    data = do_downloadpage(url)

    vid = scrapertools.find_single_match(data, "var url = '(.*?)'")

    if vid: url = vid

    if url:
        if '/cinestart.' in url: return itemlist

        elif url.startswith("https://okru.cx/?h="): return itemlist

        servidor = servertools.get_server_from_url(url)

        url = servertools.normalize_url(servidor, url)

        if servidor == 'directo':
            new_server = servertools.corregir_other(url).lower()
            if new_server.startswith("http"):
                if not config.get_setting('developer_mode', default=False): return itemlist
            servidor = new_server

        if servidor == 'zplayer': url = url + '|' + host

        itemlist.append(item.clone(server = servidor, url = url))

    return itemlist


def list_search(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    bloque = scrapertools.find_single_match(data,'Resultados de búsqueda(.*?)>Copyright')

    matches = re.compile('<a class="Posters-link"(.*?)</div></div></div>', re.DOTALL).findall(bloque)

    for article in matches:
        title = scrapertools.find_single_match(article, '<img alt="(.*?)"')

        url = scrapertools.find_single_match(article, 'href="(.*?)"')

        if not url or not title: continue

        thumb = scrapertools.find_single_match(article, 'src="(.*?)"')

        thumb = host[:1] + thumb.replace('&amp;', '&')

        url = host[:-1] + url

        tipo = 'tvshow' if '/serie/' in url else 'movie'
        sufijo = '' if item.search_type != 'all' else tipo

        if tipo == 'movie':
            if item.search_type != 'all':
                if item.search_type == 'tvshow': continue

            itemlist.append(item.clone( action='findvideos', url=url, title=title, thumbnail=thumb, fmt_sufijo = sufijo,
                                        contentType='movie', contentTitle=title, infoLabels={'year': '-'} ))

        if tipo == 'tvshow':
            if item.search_type != 'all':
                if item.search_type == 'movie': continue

            itemlist.append(item.clone( action = 'temporadas', url = url, title = title, thumbnail = thumb, fmt_sufijo = sufijo,
                                        contentType = 'tvshow', contentSerieName = title, infoLabels={'year': '-'} ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def search(item, texto):
    logger.info()
    try:
        item.url = host + 'search/' + texto.replace(" ", "+")
        return list_search(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []

