# -*- coding: utf-8 -*-

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools


def mainlist(item):
    logger.info()
    itemlist = []

    url = youtube_search(item.youtube_search)

    if url:
        video_urls = youtube_play(url)

        if video_urls: itemlist = video_urls

    return itemlist


def youtube_search(nombre):
    logger.info()

    opciones_youtube = []
    elemento_youtube = []

    i = 0

    titulo = nombre

    titulo = titulo.replace(" ", "+")

    data = httptools.downloadpage('https://www.youtube.com/results?sp=EgIQAQ%253D%253D&q=' + titulo).data

    patron  = 'thumbnails":\[\{"url":"(https://i.ytimg.com/vi[^"]+).*?'
    patron += 'text":"([^"]+).*?'
    patron += 'simpleText":"[^"]+.*?simpleText":"([^"]+).*?'
    patron += 'url":"([^"]+)'

    matches = scrapertools.find_multiple_matches(data, patron)

    for thumb, title, time, url in matches:
        if not '/watch?v=' in url: continue

        if not title: continue

        if len(title) == 1: continue

        i +=1

        url = 'https://www.youtube.com' + url

        opciones_youtube.append(platformtools.listitem_to_select('[COLOR yellow]' + title + '[/COLOR]', url))

        elemento_youtube.append([title, url])

    if i == 0:
         platformtools.dialog_notification(config.__addon_name, '[B][COLOR red]Sin Tráilers en YouTube[/B][/COLOR]')
         return ''

    ret = platformtools.dialog_select('Tráilers en Youtube', opciones_youtube)

    if ret == -1: return ''

    match = elemento_youtube[ret]

    url = match[1]

    return url


def youtube_play(ini_page_url):
    logger.info()

    video_urls = []

    if ini_page_url.startswith('https://www.youtube.com/watch?v='):
        ini_page_url = ini_page_url.replace('https://www.youtube.com/watch?v=', '')

        mvideo = re.match(r"^([0-9A-Za-z_-]{11})", ini_page_url)

        if mvideo:
           idvideo = mvideo.group(1)

           new_page_url = "https://inv.perditum.com/api/v1/videos/%s" % idvideo

           hdata = httptools.downloadpage(new_page_url).data

           if hdata:
               hvideo = scrapertools.find_single_match(hdata, '"formatStreams":.*?"url":"(.*?)"')

               if hvideo:
                   video_urls.append(['mp4', hvideo])
                   return video_urls

    return video_urls
