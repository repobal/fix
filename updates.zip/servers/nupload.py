# -*- coding: utf-8 -*-

from core import httptools, scrapertools
from platformcode import logger


host = 'https://nupload.me/'


def get_video_url(page_url, url_referer=''):
    logger.info("(page_url='%s')" % page_url)
    video_urls = []

    resp = httptools.downloadpage(page_url)

    if resp.code == 404:
        return "Archivo inexistente ó eliminado"
    elif 'Access denied' in resp.data:
        return "Acceso restringido al archivo"

    data = resp.data

    sesz = scrapertools.find_single_match(data, 'sesz="([^"]+)"')
    z_var = scrapertools.find_single_match(data, 'var [A-z]+ = \[([^\]]+)')
    base = scrapertools.find_single_match(data, 'atob.*?- (\d+)\);')

    z_var = z_var.split(",")

    vid = 'https://sv5.ibra.lat/?s=' + sesz

    url = httptools.downloadpage(vid, follow_redirects=False, only_headers=True).headers.get("location", "")

    if url:
        media_url = url + '|Referer=' + host + '&Origin=' + host

        video_urls.append(['m3u8', media_url])

    return video_urls
